#!/bin/sh
# This is a comment!
if javac Server.java ; then
	java Server
	echo "Compile Server.java OK"
else
    echo "Compile failed"
fi